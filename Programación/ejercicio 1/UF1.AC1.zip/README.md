ACTIVITAT 1 - INTRODUCCIÓ AL PSEINT. SENTÈNCIES SIMPLES.

Exercici 1. Escriu un programa que demani a l’usuari el nom i l’edat. Després ha de mostrar per pantalla: “Hola (nom), la teva edat és (edat)”;
 
Exercici 2. Realitza un programa que demani a l’usuari dos nombres i després mostri per pantalla la suma dels dos.
 
Exercici 3. Escriu un programa que demani dos variables a l’usuari, i mostri per pantalla la seva suma, resta, multiplicació, divisió i mòdul .
 
Exercici 4. Donades la base y l’altura d’un rectangle per part de l’usuari, crea un programa que calculi el àrea (Àrea = Base * Altura).
 
Exercici 5. Realitza un programa que calculi el àrea i el perímetre d’una circumferència. L’usuari haurà d’introduir el radi de la circumferència. ( A = π * r^2) ( P=2*π*r).
 
Exercici 6. Donades dos variables A y B, que l’usuari ha d’introduir, es demana un programa que intercanviï el valor de les variables.
 
Exercici 7. Escriu un programa que demani a l’usuari la quantitat de segons i mostri per pantalla a quantes hores, minuts i segons corresponen.
 
Exercici 8. Escriu un programa que mostri el resultat de l’equació de tercer grau. Per a realitzar el programa s’hauran de llegir els coeficients (a, b, c i d) i el valor de x. El resultat es mostrarà per pantalla.
 
Exercici 9. Una companyia de refrescos comercialitza tres productes: de cola, de taronja i de llimona. Es desitja realitzar un programa que calculi les ventes de cada producte. Per a això es llegirà la quantitat venuda i el preu de cada producte. Per finalitzar es mostrarà un informe de les vendes semblant a aquest:

| Producte      | Vendes        | Preu          |  Total        |
| ------------- | ------------- | ------------- | ------------- |
| Cola          | 100000        | 0,17          | 170000,00     |
| Taronja       | 350000        | 0,20          | 70000,00      |
| Llimona       | 530000        | 0,19          | 100700,00     |
|               |               | Total         | 340700,00     |

Exercici 10. Programa que demani  un nombre sencer i mostri l’últim dígit.
 
Exercici 11. Programa que demani una quantitat –preu d’un producte – i calculi i visualitzi la quantitat d’IVA (aplicant un percentatge del 21 %) i la quantitat total a pagar (preu original + Iva).
 
Exercici 12. Modifica l’exercici anterior perquè el percentatge d’IVA sigui variable (introduït per l’usuari).
 
Exercici 13. Programa que demani una quantitat en euros i determini quin era el seu valor amb les antigues “pessetes”.
 
Exercici 14. Programa que determini la edat d’un usuari (paràmetre d’entrada) quan hagi transcorregut un quart de segle
 
Exercici 15. Programa que mostri el resultat d’elevar a la quarta potència un nombre introduït per teclat. 




